"""Tests for analysis package."""
